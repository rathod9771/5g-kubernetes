project('prometheus-client-c')
