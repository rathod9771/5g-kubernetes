/**
 * Copyright 2019-2020 DigitalOcean Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <assert.h>

#ifndef PROM_ASSERT_H
#define PROM_ASSERT_H

#ifdef PROM_ASSERT_ENABLE
#define PROM_ASSERT(i) assert(i);
#else
#define PROM_ASSERT(i)
#endif  // PROM_TEST

#endif  // PROM_ASSERT_H
